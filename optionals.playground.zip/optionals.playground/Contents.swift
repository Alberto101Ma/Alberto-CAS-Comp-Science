// This is a function that returns a String? (or Optional<String>). You'll use it below.

func getFirstVowel(in name: String) -> String? {
    let vowels: [Character] = ["a", "e", "i", "o", "u", "y"]
    for char in name {
        if vowels.contains(char) {
            return String(char)
        }
    }
    return nil
}

// TODO: Change yourName to your name.

let yourName = "Alberto"

let firstVowel = getFirstVowel(in: yourName)

// TODO: Assign the underlying value of firstVowel to unwrappedVowelOne, unwrappedVowelTwo, and unwrappedVowelThree. Use a different method of unwrapping firstVowel each time.

// v-- Insert code below here --v

var unwrappedVowelOne: String
if firstVowel != nil{
    unwrappedVowelOne = firstVowel!
    print("The first vowel in '\(yourName)' is '\(unwrappedVowelOne)'.")
}else{
    print("The variable cannot be unwrapped")
}

var unwrappedVowelTwo: String
if let unwrapped = firstVowel {
    unwrappedVowelTwo = unwrapped
    print("The first vowel in '\(yourName)' is '\(unwrappedVowelTwo)'.")
}else{
    print("The variable cannot be unwrapped")
}

var unwrappedVowelThree: String = firstVowel!
print("The first vowel in '\(yourName)' is '\(unwrappedVowelThree)'.")



